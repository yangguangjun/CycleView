//
//  YCustomCell.h
//  YCycleViewDemo
//
//  Created by 杨广军 on 2020/12/16.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface YCustomCell : UICollectionViewCell

@property (nonatomic, strong) UIImage *image;

@property (nonatomic, copy) NSString *title;

@end

NS_ASSUME_NONNULL_END
