//
//  YCycleView.h
//  YCycleViewDemo
//
//  Created by 杨广军 on 2020/12/15.
//

/**
 * 注意：初始化前请确保cycleViewWithItemViewCount能获取到值，即确保确认数据源能正确返回
 * 注意：初始化前请确保cycleViewWithItemViewCount能获取到值，即确保确认数据源能正确返回
 * 注意：初始化前请确保cycleViewWithItemViewCount能获取到值，即确保确认数据源能正确返回
 **/

#import <UIKit/UIKit.h>

@class YCycleView;

NS_ASSUME_NONNULL_BEGIN

@protocol YCycleViewDataSource <NSObject>

@required
- (UIView *) cycleView:(YCycleView *)cycleView showItemView:(NSInteger)index;

- (NSInteger) cycleViewWithItemViewCount;

- (void) cycleView:(YCycleView *)cycleView setViewData:(UIView *)view index:(NSInteger)index;

@end

@protocol YCycleViewDelegate <NSObject>

@optional
- (void) cycleView:(YCycleView *)cycleView didSelectedItemView:(NSInteger)index;

@end

@interface YCycleView : UIView

@property (nonatomic, weak) id<YCycleViewDataSource> dataSource;
@property (nonatomic, weak) id<YCycleViewDelegate> delegate;

/**
 * 当前显示view下标，可以赋值初始显示view下标
 * 默认值为0
 */
@property (nonatomic, assign) NSInteger currentIndex;


/**
 * 是否在itemview上添加点击手势
 * 如果赋值yes可以调用点击的代理事件，默认为No
 */
@property (nonatomic, assign) BOOL addGesture;

/// 初始化
/// @param frame 显示frame
/// @param index 默认显示下标
/// 如果通过initWithFrame:(CGRect)frame创建对象，defaultIndex默认为0
- (instancetype) initWithFrame:(CGRect)frame defaultIndex:(NSInteger)index;


- (void) reloadData;

@end

NS_ASSUME_NONNULL_END
