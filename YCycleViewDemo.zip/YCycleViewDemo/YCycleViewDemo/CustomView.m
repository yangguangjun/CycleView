//
//  CustomView.m
//  YCycleViewDemo
//
//  Created by 杨广军 on 2020/12/16.
//

#import "CustomView.h"

@interface CustomView()

@property (nonatomic, strong) UIImageView *imageView;

@property (nonatomic, strong) UILabel *label;

@end

@implementation CustomView

- (instancetype) initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        
        _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(20, 20, frame.size.width - 40, frame.size.height - 70)];
        [self addSubview:_imageView];
        
        _label = [[UILabel alloc] initWithFrame:CGRectMake(20, frame.size.height - 50, frame.size.width - 40, 30)];
        _label.font = [UIFont systemFontOfSize:20 weight:UIFontWeightMedium];
        _label.textAlignment = NSTextAlignmentCenter;
        _label.textColor = [UIColor blackColor];
        [self addSubview:_label];
    }
    
    return self;
}

- (void) setImage:(UIImage *)image {
    _image = image;
    _imageView.image = image;

}

- (void) setTitle:(NSString *)title {
    _title = title;
    _label.text = title;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
