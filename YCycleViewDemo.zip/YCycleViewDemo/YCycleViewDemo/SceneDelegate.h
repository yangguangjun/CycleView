//
//  SceneDelegate.h
//  YCycleViewDemo
//
//  Created by 杨广军 on 2020/12/15.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

