//
//  YCycleCollectionView.m
//  YCycleViewDemo
//
//  Created by 杨广军 on 2020/12/16.
//

#import "YCycleCollectionView.h"
#import "YCustomCell.h"

@interface YCycleCollectionView()<UICollectionViewDelegate, UICollectionViewDataSource, UIScrollViewDelegate>

@property (nonatomic, copy) NSArray *imagesArr;

@end

@implementation YCycleCollectionView

- (instancetype) initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        
        _imagesArr = @[@"image_6", @"image_1", @"image_2", @"image_3" ,@"image_4", @"image_5", @"image_6", @"image_1", @"image_2", @"image_3" ,@"image_4", @"image_5", @"image_6", @"image_1"];
        
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        layout.itemSize = self.bounds.size;
        layout.minimumLineSpacing = 0;
        layout.minimumInteritemSpacing = 0;
        
        UICollectionView *collectionView = [[UICollectionView alloc] initWithFrame:self.bounds collectionViewLayout:layout];
        collectionView.pagingEnabled = YES;
        collectionView.dataSource = self;
        collectionView.delegate = self;
        collectionView.backgroundColor = [UIColor clearColor];
        [collectionView registerClass:[YCustomCell class] forCellWithReuseIdentifier:@"cell"];
        [self addSubview:collectionView];
        [collectionView scrollToItemAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:0] atScrollPosition:UICollectionViewScrollPositionNone animated:NO];
    }
    
    return self;
}

- (NSInteger) numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

- (NSInteger) collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return _imagesArr.count;
}

- (__kindof UICollectionViewCell *) collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *ID=@"cell";
    YCustomCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:ID forIndexPath:indexPath];
    cell.image = [UIImage imageNamed:_imagesArr[indexPath.row]];
    cell.title = [NSString stringWithFormat:@"%ld",(long)indexPath.row];
    
    NSLog(@"-----11-%ld-%@",(long)indexPath.row,cell);
   
    return cell;
}

- (void) scrollViewDidScroll:(UIScrollView *)scrollView {
    float pv = scrollView.contentOffset.x/scrollView.frame.size.width;
    NSInteger lpv = floor(pv) + 1;
  
    if (lpv == 0) { // 回到倒数第二页
        [scrollView setContentOffset:CGPointMake((_imagesArr.count-2)*scrollView.frame.size.width, 0) animated:NO];
    }else if (lpv == _imagesArr.count) { // 回到第二页
        [scrollView setContentOffset:CGPointMake(scrollView.frame.size.width, 0) animated:NO];
    }else {
        
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
