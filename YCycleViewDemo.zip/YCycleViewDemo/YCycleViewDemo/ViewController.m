//
//  ViewController.m
//  YCycleViewDemo
//
//  Created by 杨广军 on 2020/12/15.
//

#import "ViewController.h"
#import "YCycleView.h"
#import "CustomView.h"
#import "YCycleCollectionView.h"

@interface ViewController ()<YCycleViewDataSource, YCycleViewDelegate>

@property (nonatomic, copy) NSArray *imagesArr;
@property (nonatomic, strong) YCycleView *cycleView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
//    _imagesArr = @[@"image_1", @"image_2", @"image_3" ,@"image_4", @"image_5", @"image_6"];
//
//    _cycleView = [[YCycleView alloc] initWithFrame:CGRectMake(0, 100, self.view.frame.size.width, 300) defaultIndex:2];
//    _cycleView.dataSource = self;
//    _cycleView.delegate = self;
//    [_cycleView setAddGesture:YES];
//    [self.view addSubview:_cycleView];
    
    YCycleCollectionView *view = [[YCycleCollectionView alloc] initWithFrame:CGRectMake(0, 100, self.view.frame.size.width, 300)];
    view.backgroundColor = [UIColor redColor];
    [self.view addSubview:view];
    
}


- (NSInteger) cycleViewWithItemViewCount {
    return _imagesArr.count;
}

- (UIView *) cycleView:(YCycleView *)cycleView showItemView:(NSInteger)index{
    CustomView *customView = [[CustomView alloc] initWithFrame:cycleView.bounds];
    
    return customView;
}

- (void) cycleView:(YCycleView *)cycleView setViewData:(UIView *)view index:(NSInteger)index {
    if (![view isKindOfClass:[CustomView class]]) {
        return;
    }
  
    CustomView *customView = (CustomView *)view;
    customView.image = [UIImage imageNamed:_imagesArr[index]];
    customView.title = [NSString stringWithFormat:@"%ld",(long)(index + 1)];
}

- (void) cycleView:(YCycleView *)cycleView didSelectedItemView:(NSInteger)index {
    NSLog(@"-----tap--%ld",(index + 1));
}

@end
