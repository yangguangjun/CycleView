//
//  YCycleView.m
//  YCycleViewDemo
//
//  Created by 杨广军 on 2020/12/15.
//

#import "YCycleView.h"

static NSInteger const kReusedViewCount = 3;

@interface YCycleView()<UIScrollViewDelegate>

@property (nonatomic, strong) UIView *leftView;
@property (nonatomic, strong) UIView *centerView;
@property (nonatomic, strong) UIView *rightView;
@property (nonatomic, strong) UIPageControl *pageControl;

@property (nonatomic, assign) NSInteger dataCount;
@property (nonatomic, strong) UIScrollView *scrollView;

@end

@implementation YCycleView

- (instancetype) initWithFrame:(CGRect)frame {
    return [self initWithFrame:frame defaultIndex:0];
}

- (instancetype) initWithFrame:(CGRect)frame defaultIndex:(NSInteger)index {
    self = [super initWithFrame:frame];
    if (self) {
        _currentIndex = index;
    }
    return self;
}

- (void) initUI {
    
    if (!self.dataSource || ![self.dataSource respondsToSelector:@selector(cycleView:showItemView:)]) {
        return;
    }
    
    _dataCount = [self.dataSource cycleViewWithItemViewCount];
    if (_dataCount <= 0) {
        return;
    }
    
    _scrollView = [[UIScrollView alloc] initWithFrame:self.bounds];
    _scrollView.pagingEnabled = YES;
    _scrollView.showsVerticalScrollIndicator = NO;
    _scrollView.showsHorizontalScrollIndicator = YES;
    _scrollView.delegate = self;
    _scrollView.contentSize = CGSizeMake(_scrollView.frame.size.width*kReusedViewCount, 1);
    [self addSubview:_scrollView];
    
    CGFloat width = _scrollView.frame.size.width;
    CGFloat height = _scrollView.frame.size.height;
    _leftView = [self.dataSource cycleView:self showItemView:(_currentIndex - 1 + _dataCount)%_dataCount];
    _leftView.frame = CGRectMake(0, 0, width, height);
    _leftView.backgroundColor = [UIColor redColor];
    [_scrollView addSubview:_leftView];
    
    _centerView = [self.dataSource cycleView:self showItemView:_currentIndex];
    _centerView.frame = CGRectMake(width, 0, width, height);
    _centerView.backgroundColor = [UIColor greenColor];
    [_scrollView addSubview:_centerView];
    
    _rightView = [self.dataSource cycleView:self showItemView:(_currentIndex + 1)%_dataCount];
    _rightView.frame = CGRectMake(2*width, 0, width, height);
    _rightView.backgroundColor = [UIColor blueColor];
    [_scrollView addSubview:_rightView];
    
    // 初始化页面
    [self setViewDataWithCurrentIndex:_currentIndex];
}

/// 刷新view上显示的数据，让中间view显示当前view数据，然后滑动scrollview到中间位置，每次滑动都保持显示中间位置
/// @param index 当前显示数据的下标
- (void) setViewDataWithCurrentIndex:(NSInteger)index {
    if (!self.dataSource || ![self.dataSource respondsToSelector:@selector(cycleView:setViewData:index:)]) {
        return;
    }
    
    // 设置中间view数据
    [self.dataSource cycleView:self setViewData:_centerView index:_currentIndex];
    // 滑动到中间控件
    [_scrollView setContentOffset:CGPointMake([self scrollViewWidth], 0) animated:NO];
    // 设置左右两边view数据
    [self.dataSource cycleView:self setViewData:_leftView index:(_currentIndex - 1 + _dataCount)%_dataCount];
    [self.dataSource cycleView:self setViewData:_rightView index:(_currentIndex + 1)%_dataCount];
}


- (void) reloadData {
    
    CGPoint contentOffset = [_scrollView contentOffset];
    CGFloat scrollViewWidth = [self scrollViewWidth];
    NSLog(@"----%f---%f",scrollViewWidth, contentOffset.x);
    if (contentOffset.x > scrollViewWidth) { //向左滑动
        NSLog(@"----向左滑动");
        _currentIndex = (_currentIndex + 1) % _dataCount;
    } else if (contentOffset.x < scrollViewWidth) { //向右滑动
        NSLog(@"----向右滑动");
        _currentIndex = (_currentIndex - 1 + _dataCount) % _dataCount;
    }else {
        NSLog(@"-----未滑动");
        return;
    }
    [self setViewDataWithCurrentIndex:_currentIndex];

}

- (void) setDataSource:(id<YCycleViewDataSource>)dataSource {
    _dataSource = dataSource;
    [self initUI];
}

- (void) setAddGesture:(BOOL)addGesture {
    _addGesture = addGesture;
    if (addGesture) {
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
        [_centerView addGestureRecognizer:tap];
    }
}

- (CGFloat) scrollViewWidth {
    if (_scrollView) {
        return _scrollView.frame.size.width;
    }
    return 0;
}

- (void) tapAction:(UITapGestureRecognizer *)gesture {
    if (self.delegate && [self.delegate respondsToSelector:@selector(cycleView:didSelectedItemView:)]) {
        [self.delegate cycleView:self didSelectedItemView:_currentIndex];
    }
}

#pragma --mark UIScrollViewDelegate

- (void) scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    [self reloadData];
}




/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
