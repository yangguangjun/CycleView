//
//  AppDelegate.h
//  YCycleViewDemo
//
//  Created by 杨广军 on 2020/12/15.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow * window;


@end

